package com.example.saferecorder

import android.annotation.SuppressLint
import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.os.*
import android.provider.MediaStore
import androidx.camera.core.CameraSelector
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import java.text.SimpleDateFormat
import java.util.*

class RecorderService : LifecycleService() {

    companion object {
        const val ACTION_ARM = "arm"          // start listening for voice commands
        const val ACTION_START = "start"      // start recording
        const val ACTION_STOP = "stop"        // stop recording (keep listening)
        const val ACTION_QUIT = "quit"        // stop everything
        const val SEGMENT_MS = 5 * 60 * 1000L
        const val CH = "saferecorder"
    }

    private var provider: ProcessCameraProvider? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var wantRecording = false
    private var voice: VoiceListener? = null
    private val handler = Handler(Looper.getMainLooper())
    private val rotate = Runnable { recording?.stop() }   // Finalize callback starts next segment

    private val batteryLow = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { stopRecording() }  // finalize safely
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Recorder", NotificationManager.IMPORTANCE_LOW))
        registerReceiver(batteryLow, IntentFilter(Intent.ACTION_BATTERY_LOW))
        ProcessCameraProvider.getInstance(this).addListener(
            { provider = ProcessCameraProvider.getInstance(this).get() },
            ContextCompat.getMainExecutor(this))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_ARM -> { goForeground("Listening for \"start\""); startVoice() }
            ACTION_START -> startRecording()
            ACTION_STOP -> stopRecording()
            ACTION_QUIT -> { stopRecording(); voice?.end(); stopSelf() }
        }
        return START_NOT_STICKY
    }

    private fun goForeground(text: String) {
        ServiceCompat.startForeground(this, 1, buildNotification(text),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
    }

    private fun buildNotification(text: String): Notification {
        fun pi(action: String) = PendingIntent.getService(this, action.hashCode(),
            Intent(this, RecorderService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("SafeRecorder")
            .setContentText(text)
            .setOngoing(true)
            .addAction(0, "Start", pi(ACTION_START))
            .addAction(0, "Stop", pi(ACTION_STOP))
            .addAction(0, "Quit", pi(ACTION_QUIT))
            .build()
    }

    private fun update(text: String) =
        getSystemService(NotificationManager::class.java).notify(1, buildNotification(text))

    private fun startVoice() {
        if (voice != null) return
        voice = VoiceListener(this, "start", "stop",
            onStart = { handler.post { startRecording() } },
            onStop = { handler.post { stopRecording() } },
            onError = { handler.post { update(it) } }).also { it.begin() }
    }

    @SuppressLint("MissingPermission")
    private fun startRecording() {
        if (recording != null) return
        val p = provider ?: return
        wantRecording = true
        if (videoCapture == null) {
            val recorder = Recorder.Builder()
                .setQualitySelector(QualitySelector.from(Quality.FHD,
                    FallbackStrategy.lowerQualityOrHigherThan(Quality.HD)))
                .build()
            videoCapture = VideoCapture.withOutput(recorder)
        }
        p.unbindAll()
        p.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, videoCapture!!)   // front: DEFAULT_FRONT_CAMERA

        val name = "REC_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val cv = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/SafeRecorder")
        }
        val opts = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(cv).build()

        recording = videoCapture!!.output.prepareRecording(this, opts)
            .withAudioEnabled()
            .start(ContextCompat.getMainExecutor(this)) { ev ->
                if (ev is VideoRecordEvent.Finalize) {
                    recording = null
                    if (wantRecording) startRecording()     // next 5-min segment
                    else { provider?.unbindAll(); update("Saved. Listening for \"start\"") }
                }
            }
        update("● Recording")
    }

    private fun stopRecording() {
        wantRecording = false
        handler.removeCallbacks(rotate)
        recording?.stop()
    }

    override fun onDestroy() {
        wantRecording = false
        recording?.stop()          // finalizes the file even if service is killed
        voice?.end()
        unregisterReceiver(batteryLow)
        super.onDestroy()
    }
}

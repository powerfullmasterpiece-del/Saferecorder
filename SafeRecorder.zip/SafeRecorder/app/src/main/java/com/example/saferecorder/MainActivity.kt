package com.example.saferecorder

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Screen() } }
    }

    private fun send(action: String) =
        ContextCompat.startForegroundService(this,
            Intent(this, RecorderService::class.java).setAction(action))

    @Composable
    fun Screen() {
        var armed by remember { mutableStateOf(false) }
        val perms = buildList {
            add(Manifest.permission.CAMERA); add(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }.toTypedArray()
        val launcher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()) { r ->
            if (r.values.all { it }) { send(RecorderService.ACTION_ARM); armed = true }
        }
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("SafeRecorder", style = MaterialTheme.typography.headlineMedium)
            Text(if (armed) "Listening: say \"start\" / \"stop\" (screen off OK)"
                 else "Tap Arm first, while this app is open.")
            Button(onClick = { launcher.launch(perms) }, Modifier.fillMaxWidth()) { Text("1. Arm voice listening") }
            Button(onClick = { send(RecorderService.ACTION_START) }, Modifier.fillMaxWidth()) { Text("Start recording") }
            Button(onClick = { send(RecorderService.ACTION_STOP) }, Modifier.fillMaxWidth()) { Text("Stop recording") }
            OutlinedButton(onClick = { send(RecorderService.ACTION_QUIT); armed = false }, Modifier.fillMaxWidth()) { Text("Quit service") }
            OutlinedButton(onClick = {
                val pm = getSystemService(PowerManager::class.java)
                if (!pm.isIgnoringBatteryOptimizations(packageName))
                    startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:$packageName")))
            }, Modifier.fillMaxWidth()) { Text("Allow background (battery)") }
            Text("Videos: Gallery > Movies/SafeRecorder", style = MaterialTheme.typography.bodySmall)
        }
    }
}

# SafeRecorder – setup
1. Download https://alphacephei.com/vosk/models -> vosk-model-small-en-us-0.15.zip
2. Unzip; copy ALL its contents into app/src/main/assets/model-en-us/
3. Inside that folder create a text file named `uuid` (any text inside, e.g. "v1").
4. Open the folder in Android Studio -> Sync -> Run on phone (Android 10+).
5. Open app -> "Arm voice listening" -> allow permissions -> "Allow background (battery)".
6. Lock screen. Say "start" / "stop".
Xiaomi/Oppo/Vivo: also set Battery = Unrestricted + enable Autostart.
